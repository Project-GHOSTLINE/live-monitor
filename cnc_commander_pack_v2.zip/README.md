# C&C Bubble-Head Commander Pack

## Contents
- `public/leaders/*.png` — 8 leader portraits (PNG)
- `data/leaders/leaders_2024.json` — mapping + theme colors + readiness
- `PROMPT_CLAUDE_CNC_INTEL.md` — paste into Claude Code

## Note on labels
To avoid misinformation, the pack uses neutral UI roles (e.g., "Commander") and includes a verification date in metadata.
